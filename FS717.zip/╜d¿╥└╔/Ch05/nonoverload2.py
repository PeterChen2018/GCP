def add(x, y, z = 0):
    return x + y + z

print(add(10, 5, 3))
print(add(10, 5))



