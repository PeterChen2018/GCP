def add(x, y):
    return x + y

def add(x, y, z):
    return x + y + z


print(add(10, 5, 3))
print(add(10, 5))



