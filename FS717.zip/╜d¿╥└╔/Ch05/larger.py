def larger(x, y):
    if x > y:
        return x
    else:
        return y



print(larger(-100, -50))

