def divmod(x, y):
    div = x // y
    mod = x % y
    return div, mod

a, b = divmod(100, 7)
print("100除以7的商數為", a, "，餘數為", b)

c, d = divmod(200, 13)
print("200除以13的商數為", c, "，餘數為", d)



