def swap(x):
    temp = x[0]
    x[0] = x[1]
    x[1] = temp

a = [1, 2]
print(a)
swap(a)
print(a)


