def f1():
    x = 1
    print(x)


print(x)



