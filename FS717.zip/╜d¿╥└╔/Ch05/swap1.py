def swap(x, y):
    temp = x
    x = y
    y = temp

a, b = 1, 2
print(a, b)
swap(a, b)
print(a, b)


