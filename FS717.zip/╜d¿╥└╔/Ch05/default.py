def teaTime(dessert, drink = "紅茶"):
    print("我的甜點是", dessert, "，飲料是", drink)

teaTime("馬卡龍", "咖啡")
teaTime("帕尼尼")
teaTime(drink = "奶茶", dessert = "三明治")
teaTime("紅豆餅", drink = "綠茶")



