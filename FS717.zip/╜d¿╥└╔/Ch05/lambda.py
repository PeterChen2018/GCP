total = lambda x, y: x + y

print(total(1, 2))  
