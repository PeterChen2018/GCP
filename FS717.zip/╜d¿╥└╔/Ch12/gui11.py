from tkinter import *

def showMsg():
    i = radiovalue.get()
    if i == 0:
        messagebox.showinfo("選取結果", "繡球花")
    else:
        messagebox.showinfo("選取結果", "鬱金香")

window = Tk()
image1 = PhotoImage(file = "flower1.gif")
image2 = PhotoImage(file = "flower2.gif")
label1 = Label(window, text = "請選取您最喜歡的花：").pack()
radiovalue = IntVar()
radiovalue.set(0)
Radiobutton(window, image = image1, variable = radiovalue, value = 0).pack()
Radiobutton(window, image = image2, variable = radiovalue, value = 1).pack()
Button(window, text = "確定", command = showMsg).pack()
window.mainloop()
