from tkinter import *

def showMsg():
    label1["text"] = "Hello, World!"

window = Tk()
btn1 = Button(window, text = "顯示訊息", command = showMsg)
label1 = Label(window)
btn1.pack()
label1.pack()
window.mainloop()
