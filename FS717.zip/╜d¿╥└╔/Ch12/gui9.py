from tkinter import *

def showMsg():
    i = radiovalue.get()
    messagebox.showinfo("選取結果", dessert[i])

window = Tk()

label1 = Label(window, text = "請選取您最喜歡的甜點：").pack()
dessert = {0 : "馬卡龍", 1 : "舒芙蕾", 2 : "草莓塔", 3 : "蘋果派"}
radiovalue = IntVar()
radiovalue.set(0)
for i in range(len(dessert)):
    Radiobutton(window, text = dessert[i], variable = radiovalue, value = i).pack()
    
Button(window, text = "確定", command = showMsg).pack()
window.mainloop()

