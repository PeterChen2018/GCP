from tkinter import *
window = Tk()
btn1 = Button(window, text = "確定", bg = "yellow")
btn1["fg"] = "red"
btn1.pack()
window.mainloop()
