from tkinter import *

def newFile():
    messagebox.showinfo("開新檔案", "在此撰寫開新檔案的敘述")
    
def openFile():
    messagebox.showinfo("開啟舊檔", "在此撰寫開啟舊檔的敘述")
    
def about():
    messagebox.showinfo("關於我們", "在此撰寫關於我們的敘述")
    
window = Tk()
menu = Menu(window)
window["menu"] = menu

filemenu = Menu(menu)
menu.add_cascade(label = "檔案", menu = filemenu)
filemenu.add_command(label = "開新檔案...", command = newFile)
filemenu.add_command(label="開啟舊檔...", command = openFile)
filemenu.add_separator()
filemenu.add_command(label="離開", command = window.destroy)

helpmenu = Menu(menu)
menu.add_cascade(label = "說明", menu = helpmenu)
helpmenu.add_command(label="關於我們...", command = about)

window.mainloop()
