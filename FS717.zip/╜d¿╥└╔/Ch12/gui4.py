from tkinter import *

def add():
    result.set(num1.get() + num2.get())
    
window = Tk()

num1 = DoubleVar()
num2 = DoubleVar()
result = DoubleVar()

Entry(window, width = 10, textvariable = num1).pack(side = LEFT)
Label(window, width = 5, text = "+").pack(side = LEFT)
Entry(window, width = 10, textvariable = num2).pack(side = LEFT)
Button(window, width = 5, text = "=", command = add).pack(side = LEFT)
Entry(window, width = 10, textvariable = result).pack(side = LEFT)

window.mainloop()
