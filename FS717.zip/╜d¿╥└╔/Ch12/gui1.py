from tkinter import *
window = Tk()
window.title("我的視窗")
window.geometry("200x100")
window.maxsize(300, 200)
window.mainloop()
