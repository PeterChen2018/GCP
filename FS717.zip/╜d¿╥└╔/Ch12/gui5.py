from tkinter import *

song = "I have a pen. I have an apple, Apple pen. I have a pen. I have pineapple. \
pineapple pen, Apple pen, Pineapple pen, Pen pineapple, apple pen."

window = Tk()
text1 = Text(window, width = 40, height = 6, wrap = WORD)
text1.insert(END, "PPAP\n")
text1.insert(END, song)
text1.pack()
window.mainloop()

