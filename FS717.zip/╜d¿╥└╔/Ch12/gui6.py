from tkinter import *

song = "I have a pen. I have an apple, Apple pen. I have a pen. I have pineapple. \
pineapple pen, Apple pen, Pineapple pen, Pen pineapple, apple pen."

window = Tk()

sbar1 = Scrollbar(window)
text1 = Text(window, width = 40, height = 4, wrap = WORD)
text1.insert(END, "PPAP\n")
text1.insert(END, song)
sbar1.pack(side = RIGHT, fill = Y)
text1.pack(side = LEFT, fill = Y)
sbar1["command"] = text1.yview
text1["yscrollcommand"] = sbar1.set

window.mainloop()

