from tkinter import *

def showMsg():
    messagebox.showinfo("我的對話方塊", "Hello, World!")
    

window = Tk()
btn1 = Button(window, text = "顯示訊息", command = showMsg)
btn1.pack()
window.mainloop()

