from tkinter import *

def showMsg():
    result = ''
    for i in checkvalue:
        if checkvalue[i].get() == True:
            result = result + dessert[i] + '\t'
    messagebox.showinfo("核取結果", result)

window = Tk()

label1 = Label(window, text = "請核取您喜歡的甜點：").pack()
dessert = {0 : "馬卡龍", 1 : "舒芙蕾", 2 : "草莓塔", 3 : "蘋果派"}
checkvalue = {}
for i in range(len(dessert)):
    checkvalue[i] = BooleanVar()
    Checkbutton(window, text = dessert[i], variable = checkvalue[i]).pack()
    
Button(window, text = "確定", command = showMsg).pack()
window.mainloop()

