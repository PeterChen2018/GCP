from tkinter import *
window = Tk()
label1 = Label(window, text = "文字標籤1", width = 30, bg = "lightyellow")
label2 = Label(window, text = "文字標籤2", width = 30, bg = "lightblue")
label3 = Label(window, text = "文字標籤3", width = 30, bg = "lightgray")
label1.grid(row = 0, column = 0)
label2.grid(row = 1, column = 0)
label3.grid(row = 1, column = 1)
window.mainloop()
