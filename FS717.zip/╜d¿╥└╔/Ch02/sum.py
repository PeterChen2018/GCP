num1 = eval(input("請輸入第一個數字："))

num2 = eval(input("請輸入第二個數字："))

num3 = eval(input("請輸入第三個數字："))

total = num1 + num2 + num3

print(num1, "+", num2, "+", num3, "=", total)
