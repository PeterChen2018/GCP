print("Hello, World!")
print("Happy Birthday!")
print(5 + 2)


