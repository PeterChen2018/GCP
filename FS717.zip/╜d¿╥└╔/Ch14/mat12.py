import matplotlib.pyplot as plt

x = [70, 80, 90, 100, 110, 120, 130, 140, 150]
y = [2.2, 5.3, 11.5, 19.7, 22.9, 19.6, 11.2, 5.5, 2.1]
tl = ["<75", "75~84", "85~94", "95~104", "105~114", "115~124", "125~134", "135~144", ">144"]

plt.figure(figsize = (8, 4))
plt.bar(left = x, height = y, width = 5, label = "Sample1", tick_label = tl)
plt.legend()
plt.xlabel("Smarts")
plt.ylabel("Probability (%)")
plt.title("Bar of IQ")
plt.show()
