fileObject = open("C:\\poem.txt", "a")

fileObject.write("\n鳳凰臺上鳳凰遊，鳳去臺空江自流。")
fileObject.write("\n吳宮花草埋幽徑，晉代衣冠成古邱。")
fileObject.write("\n三山半落青又外，二水中分白鷺洲。")
fileObject.write("\n總為浮雲能蔽日，長安不見使人愁。")

fileObject.close()
