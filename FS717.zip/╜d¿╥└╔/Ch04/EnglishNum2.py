num = eval(input("請輸入1 ~ 5的整數："))
if num == 1:   
    print("ONE")
else:
    if num == 2:
        print("TWO")
    else:
        if num == 3:
            print("THREE")
        else:
            if num == 4:
                print("FOUR")
            else:
                if num == 5:
                    print("FIVE")
                else:
                    print("您輸入的資料超過範圍！")

