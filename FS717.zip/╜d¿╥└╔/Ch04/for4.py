str1 = "Hello, World!"

# 使用for迴圈逐一印出字串的每個字元和 '-' 字元
for i in str1:
    print(i, '-', end = '')
