sum = 0

for i in range(1, 7):
    sum = sum + i
else:
    print("總和等於", sum)
