x = 15
y = 10

if x > y:
    z = x - y
    print("x比y大", z)
