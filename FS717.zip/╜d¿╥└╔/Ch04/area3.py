# 將圓周率PI定義為常數
PI = 3.14159

# 取得使用者輸入的圓半徑並轉換成數值
radius = eval(input("請輸入圓半徑："))

#若圓半徑小於0，就印出提示訊息，否則印出圓面積
if radius < 0:
    print("圓半徑不能是負數")
else:
    print("半徑為", radius, "的圓面積為", PI * radius * radius)
