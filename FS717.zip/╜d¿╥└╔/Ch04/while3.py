num = eval(input("請輸入1 ~ 100的正整數："))
result = 1
i = 1

while i <= num:
    result = result * i
    i = i + 1

print(num, "階乘的值為", result)
