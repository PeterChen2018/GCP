# 匯入random模組
import random
# 隨機產生一個範圍在1 ~ 100的整數並指派給變數num
num = random.randint(1, 100)
# 變數answer用來存放使用者輸入的數字，初始值設定為 -1，表示尚未輸入
answer = -1

while answer !=  num:
    # 取得使用者輸入的數字並指派給變數answer
    answer = eval(input("請猜數字1-100："))

    if answer > num:
        print("太大了！")
    elif answer < num:
        print("太小了！")
    else:
        print("猜對了！")
