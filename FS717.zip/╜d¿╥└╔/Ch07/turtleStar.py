import turtle

turtle.color("red", "yellow")
start = turtle.position()

turtle.begin_fill()

while True:
    turtle.forward(200)
    turtle.left(170)
    if abs(turtle.position() - start) < 1:
        break
    
turtle.end_fill()

