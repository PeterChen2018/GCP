import turtle

for angle in range(0, 360, 15):
    turtle.setheading(angle)
    turtle.circle(100)
