import turtle

x = turtle.xcor()
for i in range(10):    
    turtle.circle(50)
    turtle.penup()
    x = x + 10
    turtle.goto(x, 0)
    turtle.pendown()

