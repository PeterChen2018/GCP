import turtle

# 繪製X軸，從 (-210, 0) 到 (210, 0)
turtle.penup()
turtle.goto(-210, 0)
turtle.pendown()
turtle.forward(420)

# 繪製Y軸，從 (-210, 0) 到 (210, 0)
turtle.penup()
turtle.goto(0, -210)
turtle.pendown()
turtle.left(90)
turtle.forward(420)

x1 = -200
y1 = (1 / 200) * (x1 * x1)
turtle.penup()
turtle.goto(x1, y1)
turtle.pendown()

for i in range(-199, 201):
    x2 = i
    y2 = (1 / 200) * (x2 * x2)
    turtle.goto(x2, y2)
    x1 = x2
    y1 = y2    

turtle.penup()
turtle.goto(210, -10)
turtle.pendown()
turtle.write("X軸", font = ("Arial", 16, "normal"))

turtle.penup()
turtle.goto(-10, 210)
turtle.pendown()
turtle.write("Y軸", font = ("Arial", 16, "normal"))
turtle.hideturtle()
