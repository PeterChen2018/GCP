import turtle

turtle.penup()
turtle.goto(-100, 0)
turtle.pendown()
turtle.color("red", "pink")
 
turtle.begin_fill()
turtle.circle(50)
turtle.end_fill()
 
turtle.penup()
turtle.goto(100, 0)
turtle.pendown()
turtle.color("navy", "yellow")
 
turtle.begin_fill()
turtle.circle(50, steps=3)
turtle.end_fill()
