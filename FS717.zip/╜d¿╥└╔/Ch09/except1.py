X = eval(input("請輸入被除數X："))
Y = eval(input("請輸入除數Y："))
Z = X / Y
print("X除以Y的結果等於", Z)
